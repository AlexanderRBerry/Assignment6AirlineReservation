# Assignment6_Part2

This assignment starts with an already established but unfinished project. The goal is to complete the project correcting any errors and implementing any designated features. An important aspect of this assignment is learning to adapt and improve upon someone elses work.
